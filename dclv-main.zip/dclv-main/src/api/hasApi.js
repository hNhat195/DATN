import axiosClient from "./axiosClient";

// class HasApi {
//   getListById = (data) => {
//     const url = "/product/list";
//     // const body = QueryString.stringify(data);
//     return axiosClient.post(url, data);
//   };
// }
// const productApi = new ProductApi();
// export default productApi;
