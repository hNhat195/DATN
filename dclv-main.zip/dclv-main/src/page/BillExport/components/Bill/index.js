export { default } from "./Bill";
