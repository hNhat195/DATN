export { default } from "./BillDetail";
