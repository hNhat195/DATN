export { default } from "./AnotherInfo";
