export { default } from "./BillInfo";
