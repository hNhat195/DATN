const palette = {
  primary: {
    main: "#000040",
  },
  secondary: {
    main: "#FAFAFB",
  },
  btnBg: "#1B40FA",
};
export default palette;


