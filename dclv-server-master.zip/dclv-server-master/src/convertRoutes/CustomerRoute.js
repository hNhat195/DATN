"use strict";

// module.exports = function (app) {
//   let customerCtrl = require("../controller/CustomerController");

//   app.route("/api/customer").get(customerCtrl.list);
//   app.route("/api/customer/create").post(customerCtrl.create);
//   app.route("/api/customer/:id").get(customerCtrl.infoById);
//   app.route("/api/customer/:email").get(customerCtrl.infoByEmail);
//   app.route("/api/customer/update_info").post(customerCtrl.updateInfo);
//   app.route("/api/customer/update_password").post(customerCtrl.updatePassword);
// };
